package com.adampng.services;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;

import com.adampng.domain.User;
import com.adampng.exceptions.UsernameAlreadyExistsException;
import com.adampng.repositories.UserRepository;

@Service
public class UserService {

	@Autowired
	private UserRepository userRepository;

	@Autowired
	private BCryptPasswordEncoder bCryptPasswordEncoder;

	public User saveUser(User newUser) {
		try {
			newUser.setPassword(bCryptPasswordEncoder.encode(newUser.getPassword()));
			// ensure username is unique (use custom exception)
			newUser.setUsername(newUser.getUsername());

			// ensure password and confirmPassword match
			// don't persist or show confirmPassword
			newUser.setConfirmPassword("");
			return userRepository.save(newUser);
		} catch (Exception e) {
			throw new UsernameAlreadyExistsException("Username " + newUser.getUsername() + " already exists.");
		}

	}

}
