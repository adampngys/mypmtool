package com.adampng.services;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.adampng.domain.Backlog;
import com.adampng.domain.ProjectTask;
import com.adampng.exceptions.ProjectNotFoundException;
import com.adampng.repositories.BacklogRepository;
import com.adampng.repositories.ProjectRepository;
import com.adampng.repositories.ProjectTaskRepository;

@Service
public class ProjectTaskService {

	@Autowired
	private BacklogRepository backlogRepository;

	@Autowired
	private ProjectTaskRepository projectTaskRepository;

	@Autowired
	private ProjectRepository projectRepository;

	@Autowired
	private ProjectService projectService;

	public ProjectTask addProjectTask(String projectIdentifier, ProjectTask projectTask, String username) {

		// all PTs to be added to a specific Project and the Project !=null ===> there
		// is a Backlog
		Backlog backlog = projectService.findProjectByIdentifier(projectIdentifier, username).getBacklog();// backlogRepository.findByProjectIdentifier(projectIdentifier);
		// set the bl to pt
		projectTask.setBacklog(backlog);
		// ProjectIdentifier-X where X is the PTSequence
		// e.g. ProjectIdentifier-1 ProjectIdentifier-2 ...
		Integer BacklogSequence = backlog.getPTSequence();
		// update Backlog sequence
		BacklogSequence++;
		backlog.setPTSequence(BacklogSequence);

		// Add sequence to PT
		projectTask.setProjectSequence(projectIdentifier + "-" + BacklogSequence);
		projectTask.setProjectIdentifier(projectIdentifier);

		// set initial priority when priority null
		if (projectTask.getPriority() == null || projectTask.getPriority() == 0) {
			// form
			projectTask.setPriority(3);
		}

		// initial status when status is null
		if (projectTask.getStatus() == "" || projectTask.getStatus() == null) {
			projectTask.setStatus("TO_DO");
		}
		return projectTaskRepository.save(projectTask);

	}

	public Iterable<ProjectTask> findBacklogById(String backlog_id, String username) {
		projectService.findProjectByIdentifier(backlog_id, username);
		return projectTaskRepository.findByProjectIdentifierOrderByPriority(backlog_id);
	}

	public ProjectTask findPTByProjectSequence(String backlog_id, String pt_id, String username) {
		// ensure we are searching an existing backlog
		projectService.findProjectByIdentifier(backlog_id, username);
		// ensure the task exists
		ProjectTask projectTask = projectTaskRepository.findByProjectSequence(pt_id);
		if (projectTask == null) {
			throw new ProjectNotFoundException(String.format("Project Task with ID: %s does not exist.", pt_id));
		}
		// ensure that the backlog/project id in the path corresponds to the right
		// project
		if (!projectTask.getProjectIdentifier().equals(backlog_id)) {
			throw new ProjectNotFoundException(
					String.format("Project Task with ID: %s does not exist in project: %s.", pt_id, backlog_id));
		}

		return projectTask;
	}

	public ProjectTask updateByProjectSequence(ProjectTask updatedTask, String backlog_id, String pt_id,
			String username) {
		ProjectTask projectTask = findPTByProjectSequence(backlog_id, pt_id, username);
		projectTask = updatedTask;
		return projectTaskRepository.save(projectTask);
		// update project task
		// find existing project task
		// replace it with updated task
		// save update
	}

	public void deletePTByProjectSequence(String backlog_id, String pt_id, String username) {
		ProjectTask projectTask = findPTByProjectSequence(backlog_id, pt_id, username);
		projectTaskRepository.delete(projectTask);
	}

}
